FLEXI AI — сервер Cloudflare Workers AI

Папка публикуется через GitHub Actions. В wrangler.toml настроена привязка Workers AI; ключ модели отдельно не нужен.

Нужно добавить в Settings → Secrets and variables → Actions секреты репозитория:
- CLOUDFLARE_ACCOUNT_ID — Account ID из панели Cloudflare.
- CLOUDFLARE_API_TOKEN — API token с правом Edit Cloudflare Workers.

После успешной публикации открой Cloudflare → Workers & Pages → flexi-ai-stretch и скопируй URL вида https://flexi-ai-stretch.<поддомен>.workers.dev. Вставь URL в разделе Flexi AI приложения и нажми «Сохранить адрес».

Важно: Workers AI имеет бесплатную дневную квоту, но лимиты/доступность моделей могут меняться. Не размещай API-токен в исходниках, ZIP или APK. Публичный endpoint может использовать любой человек, узнай лимиты и следи за потреблением.
