const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8",
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: corsHeaders });
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
    if (request.method === "GET" && url.pathname === "/") return json({ ok: true, service: "Flexi AI", endpoint: "/chat" });
    if (request.method !== "POST" || url.pathname !== "/chat") return json({ error: "Используй POST /chat" }, 404);
    let body;
    try { body = await request.json(); } catch { return json({ error: "Некорректный JSON" }, 400); }
    if (!Array.isArray(body.messages) || body.messages.length === 0) return json({ error: "Добавь хотя бы одно сообщение" }, 400);
    const messages = body.messages.slice(-12).map(m => {
      const role = m && m.role === "assistant" ? "assistant" : "user";
      const content = String((m && m.content) || "").slice(0, 2000);
      return { role, content };
    }).filter(m => m.content.trim());
    if (!messages.length) return json({ error: "Сообщение пустое" }, 400);
    try {
      const result = await env.AI.run("@cf/meta/llama-3.3-70b-instruct-fp8-fast", {
        messages: [
          { role: "system", content: "Ты Flexi AI — дружелюбный помощник приложения для растяжки. Отвечай на русском языке, понятно и доброжелательно. Помогай составлять умеренные планы для разных уровней подготовки. Не обещай гарантированный шпагат и не ставь диагнозы. Всегда напоминай о мягкой разминке, постепенном прогрессе, отсутствии боли и прекращении упражнения при резкой боли, онемении или головокружении. Не советуй форсировать растяжку, давить на тело или тренироваться через боль. При травме, беременности, серьёзных заболеваниях или стойкой боли советуй обсудить нагрузку с медицинским специалистом. Если просят медицинский диагноз или опасные действия, объясни ограничение и предложи безопасную альтернативу. Давай конкретные, краткие и полезные ответы." },
          ...messages
        ],
        max_tokens: 700,
        temperature: 0.6
      });
      const response = result && (result.response || result.result || result.output_text);
      if (typeof response !== "string" || !response.trim()) return json({ error: "Модель не вернула текст. Попробуй ещё раз." }, 502);
      return json({ response: response.trim() });
    } catch (error) {
      return json({ error: "Ошибка Workers AI. Проверь, включён ли Workers AI в аккаунте и доступна ли модель." }, 502);
    }
  }
};
