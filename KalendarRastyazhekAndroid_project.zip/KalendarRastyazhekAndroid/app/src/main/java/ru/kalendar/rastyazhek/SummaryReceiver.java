package ru.kalendar.rastyazhek;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class SummaryReceiver extends BroadcastReceiver {
    static final String ACTION_WEEK = "ru.kalendar.rastyazhek.WEEK_SUMMARY";
    static final String ACTION_MONTH = "ru.kalendar.rastyazhek.MONTH_SUMMARY";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        boolean weekly = ACTION_WEEK.equals(action);
        int done = countDone(context, weekly);
        int elapsed = elapsedDays(weekly);
        int missed = Math.max(0, elapsed - done);
        String title = weekly ? "Твоя сводка за неделю 💗" : "Твоя сводка за месяц 🌸";
        String text = "Растяжек: " + done + " · Пропущено дней: " + missed + " · Всего дней: " + elapsed;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, MainActivity.CHANNEL)
            : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_menu_my_calendar)
         .setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
         .setAutoCancel(true);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(weekly ? 701 : 702, b.build());
        schedule(context);
    }

    static int countDone(Context context, boolean weekly) {
        String json = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE).getString(MainActivity.RECORDS, "{}");
        int count = 0;
        try {
            JSONObject obj = new JSONObject(json);
            Calendar now = Calendar.getInstance();
            Calendar start = (Calendar) now.clone();
            if (weekly) {
                start.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
            } else {
                start.set(Calendar.DAY_OF_MONTH, 1);
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);
            }
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            for (String key : obj.keySet()) {
                if (obj.optBoolean(key, false)) {
                    Date date = fmt.parse(key);
                    if (date != null && !date.before(start.getTime()) && !date.after(now.getTime())) count++;
                }
            }
        } catch (Exception ignored) {}
        return count;
    }

    static int elapsedDays(boolean weekly) {
        Calendar now = Calendar.getInstance();
        if (weekly) return now.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? 7 : ((now.get(Calendar.DAY_OF_WEEK) + 5) % 7) + 1;
        return now.get(Calendar.DAY_OF_MONTH);
    }

    static void schedule(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        scheduleOne(context, am, ACTION_WEEK, 1, Calendar.SUNDAY, 20, 0);
        scheduleOne(context, am, ACTION_MONTH, 2, -1, 20, 0);
    }

    private static void scheduleOne(Context c, AlarmManager am, String action, int request, int dayOfWeek, int hour, int minute) {
        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, hour); when.set(Calendar.MINUTE, minute); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
        if (dayOfWeek >= 0) {
            int delta = (dayOfWeek - when.get(Calendar.DAY_OF_WEEK) + 7) % 7;
            if (delta == 0 && when.getTimeInMillis() <= System.currentTimeMillis()) delta = 7;
            when.add(Calendar.DAY_OF_YEAR, delta);
        } else {
            when.set(Calendar.DAY_OF_MONTH, when.getActualMaximum(Calendar.DAY_OF_MONTH));
            if (when.getTimeInMillis() <= System.currentTimeMillis()) {
                when.add(Calendar.MONTH, 1); when.set(Calendar.DAY_OF_MONTH, when.getActualMaximum(Calendar.DAY_OF_MONTH));
            }
        }
        Intent i = new Intent(c, SummaryReceiver.class).setAction(action);
        PendingIntent pi = PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (am != null) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }
    }
}
