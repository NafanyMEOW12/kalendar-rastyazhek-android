package ru.kalendar.rastyazhek;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends Activity {
    static final String PREFS = "stretch_data";
    static final String RECORDS = "records_json";
    static final String CHANNEL = "stretch_summaries";
    private static final int PICK_MEDIA_REQUEST = 2048;
    private WebView webView;
    private String pendingMediaDate;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createChannel();
        requestNotificationPermission();
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFFFF4F8);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(RECORDS, "{}");
                String js = "try{if(!localStorage.getItem('stretchCalendar.v1') || localStorage.getItem('stretchCalendar.v1')==='{}'){localStorage.setItem('stretchCalendar.v1', " +
                    JSONObject.quote(saved) + ");}}catch(e){}";
                view.evaluateJavascript(js, null);
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        SummaryReceiver.schedule(this);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Сводки о растяжке", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Еженедельная и ежемесячная статистика растяжек");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    public class AndroidBridge {
        private final MainActivity activity;
        AndroidBridge(MainActivity a) { activity = a; }

        @JavascriptInterface public void saveRecords(String json) {
            activity.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(RECORDS, json).apply();
        }

        @JavascriptInterface public void pickMedia(String dateKey) {
            activity.pendingMediaDate = dateKey;
            activity.runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    activity.startActivityForResult(intent, PICK_MEDIA_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(activity, "Не удалось открыть выбор файлов", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_MEDIA_REQUEST || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri source = data.getData();
        String mime = getContentResolver().getType(source);
        if (mime == null || !(mime.startsWith("image/") || mime.startsWith("video/"))) {
            sendMediaError("Выбери изображение или видео");
            return;
        }
        try {
            File folder = new File(getFilesDir(), "stretch_media");
            if (!folder.exists() && !folder.mkdirs()) throw new Exception("Не удалось создать папку");
            String ext = mime.startsWith("video/") ? ".mp4" : ".jpg";
            String originalName = displayName(source);
            int dot = originalName.lastIndexOf('.');
            if (dot >= 0 && dot < originalName.length() - 1) {
                String candidate = originalName.substring(dot).replaceAll("[^a-zA-Z0-9.]", "");
                if (candidate.length() <= 8) ext = candidate;
            }
            File dest = new File(folder, UUID.randomUUID().toString() + ext);
            try (InputStream in = getContentResolver().openInputStream(source);
                 FileOutputStream out = new FileOutputStream(dest)) {
                if (in == null) throw new Exception("Не удалось прочитать файл");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            JSONObject result = new JSONObject();
            result.put("date", pendingMediaDate == null ? "" : pendingMediaDate);
            result.put("url", Uri.fromFile(dest).toString());
            result.put("type", mime.startsWith("video/") ? "video" : "image");
            result.put("name", originalName);
            final String js = "window.onNativeMediaPicked && window.onNativeMediaPicked(" + JSONObject.quote(result.toString()) + ");";
            if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            sendMediaError("Не удалось сохранить файл. Проверь свободное место на телефоне.");
        }
    }

    private String displayName(Uri uri) {
        String name = "Медиафайл";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return name == null ? "Медиафайл" : name;
    }

    private void sendMediaError(String message) {
        if (webView != null) webView.post(() -> webView.evaluateJavascript(
            "window.onNativeMediaError && window.onNativeMediaError(" + JSONObject.quote(message) + ")", null));
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
