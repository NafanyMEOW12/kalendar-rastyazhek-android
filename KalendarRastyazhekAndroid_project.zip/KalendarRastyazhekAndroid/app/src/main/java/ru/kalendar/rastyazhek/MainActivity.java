package ru.kalendar.rastyazhek;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.Calendar;

public class MainActivity extends Activity {
    static final String PREFS = "stretch_data";
    static final String RECORDS = "records_json";
    static final String CHANNEL = "stretch_summaries";
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        createChannel();
        requestNotificationPermission();
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFFFF4F8);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                String saved = getPreferences(MODE_PRIVATE).getString(RECORDS, "{}");
                String js = "try{if(!localStorage.getItem('stretchCalendar.v1') || localStorage.getItem('stretchCalendar.v1')==='{}'){localStorage.setItem('stretchCalendar.v1', " +
                    JSONObject.quote(saved) + ");}}catch(e){}";
                view.evaluateJavascript(js, null);
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        SummaryReceiver.schedule(this);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Сводки о растяжке", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Еженедельная и ежемесячная статистика растяжек");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context c) { context = c.getApplicationContext(); }
        @JavascriptInterface public void saveRecords(String json) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(RECORDS, json).apply();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
